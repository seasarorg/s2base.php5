<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE components PUBLIC "-//SEASAR//DTD S2Container//EN"
"http://www.seasar.org/dtd/components21.dtd">
<components>
    <!--
    <include path="%S2BASE_PHP5_ROOT%/app/modules/module/dicon/dao.dicon"/>
    <component class="ClassName">
        <property name="name">value</property>
        <aspect>dao.interceptor</aspect>
    </component>
    -->
</components>
