<?php
class @@CLASS_NAME@@ 
    implements @@INTERFACE_NAME@@{
    public function __construct(){}
}
?>
