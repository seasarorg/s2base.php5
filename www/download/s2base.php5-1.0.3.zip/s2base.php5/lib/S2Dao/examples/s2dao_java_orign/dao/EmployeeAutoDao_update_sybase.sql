UPDATE EMP SET ENAME = /*employee.ename*/'SCOTT'
WHERE EMPNO = convert('INT', /*employee.empno*/7788)
