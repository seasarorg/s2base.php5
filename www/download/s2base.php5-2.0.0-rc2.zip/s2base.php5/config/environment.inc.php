<?php
require_once('s2base.inc.php');
