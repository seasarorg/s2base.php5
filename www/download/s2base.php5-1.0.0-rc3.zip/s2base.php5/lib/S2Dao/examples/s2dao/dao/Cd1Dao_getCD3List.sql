SELECT *
FROM CD
WHERE
/*IF id != null*/ ID = /*id*/'1'
--ELSE ID = 1
/*END*/
