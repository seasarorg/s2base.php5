<?php
interface Employee2Dao {
    public function getEmployees($ename);
    public function getEmployee($eno);
}
?>
