<?php
class @@CLASS_NAME@@ {
    const TABLE = "@@TABLE_NAME@@";
    public function __construct(){}

@@ACCESSOR@@
@@TO_STRING@@

    /*
    private $prop;
    const prop_RELNO = 0;
    const prop_RELKEYS = 'this_fk:other_pk';
    public function setProp(Entity $entity){ $this->prop = $entity; }
    public function getProp(){ return $this->prop; }
    */    
}
?>
