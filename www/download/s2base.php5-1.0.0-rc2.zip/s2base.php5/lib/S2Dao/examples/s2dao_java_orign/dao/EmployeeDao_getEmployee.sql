SELECT EMP.*, DEPT.dname as dname_0, DEPT.loc as loc_0 FROM EMP, DEPT
WHERE EMP.empno = /*empno*/7788 AND EMP.deptno = DEPT.deptno
