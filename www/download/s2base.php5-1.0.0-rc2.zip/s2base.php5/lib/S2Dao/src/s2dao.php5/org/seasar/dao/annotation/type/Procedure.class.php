<?php

/**
 * @author nowel
 */
class Procedure {
    public $value;
}
?>