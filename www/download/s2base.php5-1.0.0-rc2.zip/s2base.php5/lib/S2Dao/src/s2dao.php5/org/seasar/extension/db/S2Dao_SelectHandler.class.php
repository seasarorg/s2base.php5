<?php

/**
 * @author nowel
 */
interface S2Dao_SelectHandler {
    public function execute($element, $args);
}
?>
