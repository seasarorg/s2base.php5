<?php

/**
 * @author nowel
 */
interface S2Dao_ResultSetFactory {
    public function createResultSet(PDOStatement $ps);
}
?>
