<?php

interface S2Dao_PHPType {
    const Boolean = 'boolean';
    const Integer = 'integer';
    const Double = 'double';
    const Float = 'float';
    const String = 'string';
    const Object = 'object';
    const Resource = 'resource';
    const Null = 'NULL';
    const Unkwown = 'unknown type';
}
?>