<?php

/**
 * @author nowel
 */
final class Bean {
    public $table = '';
    public $noPersistentProperty = array();
    public $versionNoProperty = 'versionNo';
    public $timeStampProperty = 'timestamp';
}

?>