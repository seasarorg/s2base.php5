<?php

/**
 * @author nowel
 */
interface S2Dao_RowStates {
    
    const UNCHANGED = 'UNCHANGED';
    const CREATED = 'CREATED';
    const MODIFIED = 'MODIFIED';
    const REMOVED = 'REMOVED';
}
?>