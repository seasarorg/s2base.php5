<?php

/**
 * @author nowel
 */
interface S2Dao_IdentifierGenerator {
    public function isSelfGenerate();
    //public function setIdentifier($bean, $ds);
}
?>
