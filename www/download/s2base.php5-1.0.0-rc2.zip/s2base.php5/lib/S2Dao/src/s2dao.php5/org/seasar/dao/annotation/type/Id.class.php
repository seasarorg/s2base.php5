<?php

/**
 * @author nowel
 */
class Id {
    public $value = 'assigned';
    public $sequenceName;
}
?>