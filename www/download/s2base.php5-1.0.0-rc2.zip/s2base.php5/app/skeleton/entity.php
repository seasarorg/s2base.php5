<?php
class @@CLASS_NAME@@ {
    const TABLE = "@@TABLE_NAME@@";
    public function __construct(){}

@@ACCESSOR@@
}
?>
