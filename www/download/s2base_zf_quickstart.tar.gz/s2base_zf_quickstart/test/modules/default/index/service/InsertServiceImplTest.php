<?php
class InsertServiceImplTest extends PHPUnit2_Framework_TestCase {
    private $module = "default";
    private $controller = "index";
    private $container;
    private $service;
    
    function __construct($name) {
        parent::__construct($name);
    }

    function testA() {
    }

    function setUp(){
        print __CLASS__ . "::{$this->getName()}\n";
        $controllerDir = S2BASE_PHP5_ROOT . "/app/modules/{$this->module}/{$this->controller}";
        $dicon = $controllerDir . "/dicon/InsertServiceImpl" . S2BASE_PHP5_DICON_SUFFIX;
        include_once($controllerDir . "/{$this->controller}.inc.php");
        $this->container = S2ContainerFactory::create($dicon);
        $this->service = $this->container->getComponent("InsertService");
    }

    function tearDown() {
        print "\n";
        $this->container = null;
        $this->service = null;
    }

}
?>
