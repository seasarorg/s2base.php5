<?php
class IndexController extends Zend_Controller_Action {
    private $service = null;

    public function indexAction() {}

    public function topAction() {
        $this->view->assign('dtos', $this->service->getWithLimit(-1));
    }

    public function insertConfirmAction(){
        $dto = new KeijibanEntity();
        $dto->setName($this->getRequest()->getParam('handle'));
        $dto->setComment($this->getRequest()->getParam('comment'));
        $this->view->assign('dto', $dto);
        $sn = new Zend_Session_Namespace('start_insert');
        $sn->dto = $dto;
    }

    public function insertAction() {
        $sn = new Zend_Session_Namespace('start_insert');
        $this->service->insert($sn->dto);
        Zend_Session::destroy();
        $this->_redirect("/{$this->getRequest()->getControllerName()}/top");
    }
    /** S2BASE_PHP5 ACTION METHOD **/

    public function setService(IndexService $service) {
        $this->service = $service;
    }
}
?>
