<?php
interface IndexService {
}
?>
