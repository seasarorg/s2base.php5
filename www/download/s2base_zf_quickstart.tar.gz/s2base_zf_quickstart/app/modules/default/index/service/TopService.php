<?php
interface TopService {
    public function getWithLimit($limit);
}
?>
