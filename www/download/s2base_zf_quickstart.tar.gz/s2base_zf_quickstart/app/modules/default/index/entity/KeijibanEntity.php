<?php
class KeijibanEntity {
    const TABLE = "keijiban";
    public function __construct(){}

    protected $id;
    const id_COLUMN = "id";
    public function setId($val){$this->id = $val;}
    public function getId(){return $this->id;}

    protected $name;
    const name_COLUMN = "name";
    public function setName($val){$this->name = $val;}
    public function getName(){return $this->name;}

    protected $comment;
    const comment_COLUMN = "comment";
    public function setComment($val){$this->comment = $val;}
    public function getComment(){return $this->comment;}

    protected $timestamp;
    const timestamp_COLUMN = "timestamp";
    public function setTimestamp($val){$this->timestamp = $val;}
    public function getTimestamp(){return $this->timestamp;}


    public function __toString() {
        $buf = array();
        $buf[] = 'id => ' . $this->getId();
        $buf[] = 'name => ' . $this->getName();
        $buf[] = 'comment => ' . $this->getComment();
        $buf[] = 'timestamp => ' . $this->getTimestamp();
        return '{' . implode(', ',$buf) . '}';
    }


    /*
    private $prop;
    const prop_RELNO = 0;
    const prop_RELKEYS = 'this_fk:other_pk';
    public function setProp(OtherEntity $entity){ $this->prop = $entity; }
    public function getProp(){ return $this->prop; }
    */    
}
?>
