<?php
interface KeijibanDao {
    const BEAN = "KeijibanEntity";
    
    public function findAllList();
    public function findWithLimitList($limit);
    //public function findAllArray();
    //public function update(KeijibanEntity $entity);
    public function insert(KeijibanEntity $entity);
    //public function delete(KeijibanEntity $entity);
}
?>
