<?php
/**
 * available properties.
 *    protected $invocation;
 *    protected $request;
 *    protected $moduleName;
 *    protected $actionName;
 *    protected $action;
 *    protected $view;
 *    protected $controller;
 */
class @@CLASS_NAME@@ extends S2Base_AbstractAfterFilter {
    public function after($result){
        return $result;
    }
}
?>
