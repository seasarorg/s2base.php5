<?php
class @@CLASS_NAME@@ 
    implements @@INTERFACE_NAME@@ {
    private $dao;

    public function __construct(){}

    public function setDao(@@DAO_NAME@@ $dao){
        $this->dao = $dao;
    } 
}
?>
