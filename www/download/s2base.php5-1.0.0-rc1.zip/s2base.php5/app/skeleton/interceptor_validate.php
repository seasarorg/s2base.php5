<?php
/**
 * available properties.
 *    protected $invocation;
 *    protected $request;
 *    protected $moduleName;
 *    protected $actionName;
 *    protected $action;
 *    protected $view;
 *    protected $rule;
 *    protected $controller;
 */
class @@CLASS_NAME@@ extends S2Base_AbstractValidateFilter {
    public function getSuffix(){
        return "@@CLASS_NAME@@";
    }

    public function validate(){
        return null;
    }
}
?>
