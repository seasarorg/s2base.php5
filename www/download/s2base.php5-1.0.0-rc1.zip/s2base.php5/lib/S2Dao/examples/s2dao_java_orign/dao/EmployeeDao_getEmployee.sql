SELECT EMP.*, DEPT.dname dname_0, DEPT.loc loc_0 FROM EMP, DEPT
WHERE EMP.empno = /*empno*/7788 AND EMP.deptno = DEPT.deptno
