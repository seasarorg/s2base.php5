<?php

/**
 * @author nowel
 */
class Column {
    public $value;
}
?>