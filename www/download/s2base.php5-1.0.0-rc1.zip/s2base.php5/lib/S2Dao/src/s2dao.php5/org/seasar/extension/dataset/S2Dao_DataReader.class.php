<?php

/**
 * @author nowel
 */
interface S2Dao_DataReader {

    public function read();

}
?>