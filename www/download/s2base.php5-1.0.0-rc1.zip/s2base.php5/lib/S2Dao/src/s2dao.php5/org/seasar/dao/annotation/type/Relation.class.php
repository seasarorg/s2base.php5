<?php

/**
 * @author nowel
 */
class Relation {
    public $relationNo;
    public $relationKey = '';
}
?>