<?php

/**
 * @author nowel
 */
class Query {
    public $value;
}
?>