<?php

/**
 * @author nowel
 */
interface S2Dao_ProcedureHandler {
	public function execute(array $args);
}

?>