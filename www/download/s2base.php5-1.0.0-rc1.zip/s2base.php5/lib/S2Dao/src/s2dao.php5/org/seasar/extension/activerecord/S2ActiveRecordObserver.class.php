<?php

/**
 * @author nowel
 */
class S2ActiveRecordObserver {
}

?>