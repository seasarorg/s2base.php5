<?php

/**
 * @author nowel
 */
class NoPersistentProperty {
    public $value = array();
}
?>