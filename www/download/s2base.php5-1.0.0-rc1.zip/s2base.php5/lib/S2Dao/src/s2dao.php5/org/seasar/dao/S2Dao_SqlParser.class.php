<?php

/**
 * @author nowel
 */
interface S2Dao_SqlParser {
    public function parse();
}
?>
