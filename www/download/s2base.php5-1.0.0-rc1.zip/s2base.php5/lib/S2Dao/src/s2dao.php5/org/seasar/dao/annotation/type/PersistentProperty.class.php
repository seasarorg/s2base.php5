<?php

/**
 * @author nowel
 */
class PersistentProperty {
    public $value = array();
}
?>