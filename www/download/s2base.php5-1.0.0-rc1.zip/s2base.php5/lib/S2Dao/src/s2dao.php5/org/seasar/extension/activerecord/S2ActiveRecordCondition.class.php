<?php

/**
 * @author nowel
 */
class S2ActiveRecordCondition {
}

?>