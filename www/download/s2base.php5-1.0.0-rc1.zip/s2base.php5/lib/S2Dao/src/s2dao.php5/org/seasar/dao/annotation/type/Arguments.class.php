<?php

/**
 * @author nowel
 */
class Arguments {
    public $value = array();
}
?>