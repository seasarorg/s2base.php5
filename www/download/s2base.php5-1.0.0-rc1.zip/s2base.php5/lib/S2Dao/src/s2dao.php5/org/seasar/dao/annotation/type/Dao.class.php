<?php

/**
 * @author nowel
 */
class Dao {
    
    public $bean;
    
}

?>