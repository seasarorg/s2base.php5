<?php

/**
 * @author nowel
 */
interface S2Dao_SqlCommand {
    public function execute($args);
}

?>
