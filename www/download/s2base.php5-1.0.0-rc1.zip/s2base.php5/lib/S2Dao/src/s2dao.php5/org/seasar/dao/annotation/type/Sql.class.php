<?php

/**
 * @author nowel
 */
class Sql {
    public $value;
    public $dbms;
}
?>