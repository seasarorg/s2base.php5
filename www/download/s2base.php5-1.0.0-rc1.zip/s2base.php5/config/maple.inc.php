<?php
require_once('environment.inc.php');

/**
 * cache switch
define('S2AOP_PHP5_FILE_CACHE',true);
define('S2AOP_PHP5_FILE_CACHE_DIR', S2BASE_PHP5_VAR_DIR . '/cache');
define('S2CONTAINER_PHP5_CACHE_DIR',S2BASE_PHP5_VAR_DIR . '/cache');
 */
?>
