<?php
class @@CLASS_NAME@@
    implements S2Base_GenerateCommand {

    public function getName(){
        return "@@COMMAND_NAME@@";
    }

    public function execute(){
    }

}
?>
