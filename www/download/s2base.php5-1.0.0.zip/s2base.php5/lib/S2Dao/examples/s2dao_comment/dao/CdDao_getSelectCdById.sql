select * from CD where ID = /*id*/1
