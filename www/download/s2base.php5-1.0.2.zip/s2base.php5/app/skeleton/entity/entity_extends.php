<?php
class @@CLASS_NAME@@ extends @@EXTENDS_CLASS@@{
    public function __construct(){}

@@ACCESSOR@@
@@TO_STRING@@

    /*
    private $prop;
    const prop_RELNO = 0;
    const prop_RELKEYS = 'this_fk:other_pk';
    public function setProp(OtherEntity $entity){ $this->prop = $entity; }
    public function getProp(){ return $this->prop; }
    */
}
?>
