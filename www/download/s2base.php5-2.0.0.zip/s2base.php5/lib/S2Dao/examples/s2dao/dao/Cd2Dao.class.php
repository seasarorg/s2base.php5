<?php

interface Cd2Dao {
    const BEAN = "CdBean";
    public function getCd($id);
}
?>
