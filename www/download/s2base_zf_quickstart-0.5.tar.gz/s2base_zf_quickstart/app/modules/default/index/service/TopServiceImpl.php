<?php
class TopServiceImpl 
    implements TopService, IndexService {
    private $keijibanDao;

    public function __construct(){}

    public function getWithLimit($limit) {
        $arrayobject = $this->keijibanDao->findAllList();
        if ($limit < 0 or $limit > $arrayobject->count()) {
            return $arrayobject;
        }
        $dtos = new ArrayObject();
        for ($i = 0; $i < $limit; $i++) {
            $dtos->append($arrayobject->offsetGet($i));
        }
        return $dtos;
    }

    public function setKeijibanDao(KeijibanDao $dao){
        $this->keijibanDao = $dao;
    } 
}
?>
