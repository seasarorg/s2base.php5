<?php
class InsertServiceImpl 
    implements InsertService, IndexService {
    private $keijibanDao;

    public function __construct(){}

    public function insert(KeijibanEntity $dto) {
        $this->keijibanDao->insert($dto);
    }

    public function setKeijibanDao(KeijibanDao $dao){
        $this->keijibanDao = $dao;
    } 
}
?>
