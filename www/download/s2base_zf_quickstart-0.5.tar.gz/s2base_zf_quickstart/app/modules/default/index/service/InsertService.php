<?php
interface InsertService {
    public function insert(KeijibanEntity $dto);
}
?>
