<?php
class IndexController extends Zend_Controller_Action {
    private $service = null;

    public function indexAction() {}

    public function topAction() {
        $this->view->assign('dtos', $this->service->getWithLimit(-1));
    }

    public function insertConfirmAction(){
        $dto = new KeijibanEntity();
        $dto->setName($this->getRequest()->getParam('handle'));
        $dto->setComment($this->getRequest()->getParam('comment'));
        $this->view->assign('dto', $dto);
        $sn = new Zend_Session_Namespace('start_insert');
        $sn->dto = $dto;
    }

    public function insertAction() {
        $sn = new Zend_Session_Namespace('start_insert');
        $this->service->insert($sn->dto);
        Zend_Session::destroy();
        $this->_redirect("/{$this->getRequest()->getControllerName()}/top");
    }
    /** S2BASE_PHP5 ACTION METHOD **/

    public function __call($methodName, $args) {}

    public function preDispatch() {}

    public function postDispatch() {
        $this->render($this->getRequest()->getActionName());
    }

    public function setService(IndexService $service) {
        $this->service = $service;
    }

    public function setView(Zend_View_Interface $view) {
        $this->view = $view;
        if ($this->view instanceof S2Base_ZfView) {
            $this->viewSuffix = S2BASE_PHP5_ZF_TPL_SUFFIX;
        }
    }

    public function render($script, $name = null) {
        parent::render($script, $name, true);
    }
}
?>
