<?php
class KeijibanDaoTest extends PHPUnit2_Framework_TestCase {
    private $module = "default";
    private $controller = "index";
    private $container;
    private $dao;
    
    function __construct($name) {
        parent::__construct($name);
    }

    function testFindAllList() {
        $dtos = $this->dao->findAllList();
        foreach ($dtos as $dto) {
            print $dto;
        }
    }

    function setUp(){
        print __CLASS__ . "::{$this->getName()}\n";
        $controllerDir = S2BASE_PHP5_ROOT . "/app/modules/{$this->module}/{$this->controller}";
        $dicon = $controllerDir . "/dicon/TopServiceImpl" . S2BASE_PHP5_DICON_SUFFIX;
        include_once($controllerDir . "/{$this->controller}.inc.php");
        $this->container = S2ContainerFactory::create($dicon);
        $this->dao = $this->container->getComponent("KeijibanDao");
    }

    function tearDown() {
        print "\n";
        $this->container = null;
        $this->dao = null;
    }

}
?>
