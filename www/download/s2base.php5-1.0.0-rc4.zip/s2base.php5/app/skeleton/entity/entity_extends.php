<?php
class @@CLASS_NAME@@ extends @@EXTENDS_CLASS@@{
    public function __construct(){}

@@ACCESSOR@@
@@TO_STRING@@
}
?>
