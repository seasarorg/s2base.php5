<?php
interface @@CLASS_NAME@@ {
}
?>
