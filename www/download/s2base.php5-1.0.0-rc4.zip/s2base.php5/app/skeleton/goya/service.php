<?php
class @@CLASS_NAME@@ 
    implements @@INTERFACE_NAME@@ {
    private $@@DAO_PROPERTY@@;

    public function __construct(){}

    public function set@@DAO_NAME@@(@@DAO_NAME@@ $dao){
        $this->@@DAO_PROPERTY@@ = $dao;
    } 
}
?>
