<?php
/* vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4: */
// +----------------------------------------------------------------------+
// | PHP version 5                                                        |
// +----------------------------------------------------------------------+
// | Copyright 2005-2006 the Seasar Foundation and the Others.            |
// +----------------------------------------------------------------------+
// | Licensed under the Apache License, Version 2.0 (the "License");      |
// | you may not use this file except in compliance with the License.     |
// | You may obtain a copy of the License at                              |
// |                                                                      |
// |     http://www.apache.org/licenses/LICENSE-2.0                       |
// |                                                                      |
// | Unless required by applicable law or agreed to in writing, software  |
// | distributed under the License is distributed on an "AS IS" BASIS,    |
// | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,                        |
// | either express or implied. See the License for the specific language |
// | governing permissions and limitations under the License.             |
// +----------------------------------------------------------------------+
// | Authors: klove                                                       |
// +----------------------------------------------------------------------+
//
// $Id: S2Container_AbstractComponentAutoRegister.class.php 402 2006-10-23 14:25:15Z klove $
/**
 * @package org.seasar.extension.autoregister.impl
 * @author klove
 */
abstract class S2Container_AbstractComponentAutoRegister 
    extends S2Container_AbstractAutoRegister 
{
    private $autoNaming = null;
    private $instanceMode = "singleton";

    /**
     * 
     */
    public function __construct()
    {
        $this->autoNaming = new S2Container_DefaultAutoNaming();
    }

    /**
     * 
     */
    public function getAutoNaming()
    {
        return $this->autoNaming;
    }
    
    /**
     * 
     */
    public function setAutoNaming(S2Container_AutoNaming $autoNaming)
    {
        $this->autoNaming = $autoNaming;
    }
    
    /**
     * 
     */
    public function getInstanceMode()
    {
        return $this->instanceMode;
    }

    /**
     * 
     */
    public function setInstanceMode($instanceMode)
    {
        $this->instanceMode = $instanceMode;
    }
   
    /**
     * 
    public function processClass($classFilePath, $className)
    {
        if ($this->isIgnore($className)) {
            return;
        }
    
        $c = $this->getClassPatternSize();
        for ($i = 0; $i < $c; ++$i) {
            $cp = $this->getClassPattern($i);
            if ($cp->isAppliedShortClassName($className)) {
                $this->register($classFilePath, $className);
            }
        }
    }
     */

    /**
     * 
     */
    protected function register($classFilePath, $className)
    {
        if (!class_exists($className,false)) {
            require_once($classFilePath);
        }
        
        $annoHandler = S2Container_AnnotationHandlerFactory::getAnnotationHandler();
        $cd = $annoHandler->createComponentDef(new ReflectionClass($className),
                                               $this->instanceMode);
        if ($cd->getComponentName() == null and
            $this->autoNaming != null) {
            $cd->setComponentName($this->autoNaming->
                                  defineName($classFilePath,$className));
        }
        $annoHandler->appendDI($cd);
        $annoHandler->appendAspect($cd);
        $annoHandler->appendInitMethod($cd);
        $this->getContainer()->register($cd);
    }
}
?>
