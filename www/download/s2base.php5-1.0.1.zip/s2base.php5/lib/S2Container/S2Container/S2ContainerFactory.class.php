<?php
/* vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4: */
// +----------------------------------------------------------------------+
// | PHP version 5                                                        |
// +----------------------------------------------------------------------+
// | Copyright 2005-2006 the Seasar Foundation and the Others.            |
// +----------------------------------------------------------------------+
// | Licensed under the Apache License, Version 2.0 (the "License");      |
// | you may not use this file except in compliance with the License.     |
// | You may obtain a copy of the License at                              |
// |                                                                      |
// |     http://www.apache.org/licenses/LICENSE-2.0                       |
// |                                                                      |
// | Unless required by applicable law or agreed to in writing, software  |
// | distributed under the License is distributed on an "AS IS" BASIS,    |
// | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,                        |
// | either express or implied. See the License for the specific language |
// | governing permissions and limitations under the License.             |
// +----------------------------------------------------------------------+
// | Authors: klove                                                       |
// +----------------------------------------------------------------------+
//
// $Id: S2ContainerFactory.class.php 340 2006-08-20 09:40:43Z klove $
/**
 * @package org.seasar.framework.container.factory
 * @author klove
 */
final class S2ContainerFactory
{
    public static $BUILDERS = array();

    private static $instance = null;
    private static $builders_ = array();
    private static $processingPaths_ = array();

    private function __construct()
    {
    }
    
    /**
     * @param string dicon path 
     */
    public static function create($path) 
    {
        self::_enter($path);
        $ext = pathinfo($path,PATHINFO_EXTENSION);
        $container = null;
        try {
            $container = self::_getBuilder($ext)->build($path);
            self::_leave($path);
        } catch (Exception $e) {
            self::_leave($path);
            throw $e;
        }

        return $container;
    }
    
    /**
     * 
     */
    public static function includeChild(S2Container $parent, $path)
    {
        self::_enter($path);
        $root = $parent->getRoot();
        $child = null;
        try {
            if ($root->hasDescendant($path)) {
                $child = $root->getDescendant($path);
                $parent->includeChild($child);
            } else {
                $ext = pathinfo($path,PATHINFO_EXTENSION);
                $builder = self::_getBuilder($ext);
                $child = $builder->includeChild($parent,$path);
                $root->registerDescendant($child);
            }
            self::_leave($path);

        } catch (Exception $e) {
            self::_leave($path);
            throw $e;
        }

        return $child;
    }

    /**
     * 
     */
    private static function _getBuilder($ext)
    {
        $builder = null;

        if (array_key_exists($ext,self::$builders_)) {
            return self::$builders_[$ext];
        }

        $className = array_key_exists($ext,self::$BUILDERS) 
                     ? self::$BUILDERS[$ext]
                     : null;
        if ($className != null) {
            $builder = new $className();
            if (!$builder instanceof S2ContainerBuilder) {
                throw new S2Container_S2RuntimeException('ESSR1011',
                    array($ext,$className),
                    null);
            }
            self::$builders_[$ext] = $builder;
        } else {
            throw new S2Container_S2RuntimeException('ESSR1012',
                array($ext),
                null);
        }
        return $builder;
    }

    /**
     * 
     */
    private static function _enter($path)
    {
        if (in_array($path,self::$processingPaths_)) {
            throw new S2Container_CircularIncludeRuntimeException($path,
                                  self::$processingPaths_);
        }
        array_push(self::$processingPaths_,$path);
    }

    /**
     * 
     */
    private static function _leave($path)
    {
        array_pop(self::$processingPaths_);
    }
}
?>
