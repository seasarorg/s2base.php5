<?php

interface ShelfSearchCdDao {
    const BEAN = "ShelfSearchCdBean";
    public function getAllShelfList();
}

?>
